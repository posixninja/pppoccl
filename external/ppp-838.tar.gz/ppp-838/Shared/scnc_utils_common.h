/*
 * Copyright (c) 2013 Apple Inc.
 * All rights reserved.
 */

#ifndef __SCNC_UTILS_COMMON_H__
#define __SCNC_UTILS_COMMON_H__

extern int setup_security_context(void);

#endif /*  __SCNC_UTILS_COMMON_H__ */
