/*
 * Copyright (c) 2013 Apple Inc.
 * All rights reserved.
 */

#ifndef __SANDBOX_INFO_H__
#define __SANDBOX_INFO_H__

int launch_setup_env(int argc, const char * argv[]);

#endif /* __SANDBOX_INFO_H__ */
