/* $Id: patchlevel.h,v 1.5 2004/02/10 19:29:23 callie Exp $ */

#define VERSION		"2.4.2"
#define DATE		"13 Jan 2004"
