#!/bin/bash
touch /tmp/winning
